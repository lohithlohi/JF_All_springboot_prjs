package com.bookstore.order_service.dataModel;

public enum OrderStatus {
    PENDING, CONFIRMED, CANCELLED
}